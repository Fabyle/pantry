<?xml version='1.0' encoding='ISO-8859-1'?>
<!DOCTYPE helpset PUBLIC "-//Sun Microsystems Inc.//DTD JavaHelp HelpSet Version 1.0//EN"
                         "http://java.sun.com/products/javahelp/helpset_1_0.dtd">

<!-- Copyright 2004 Sun Microsystems, Inc. All Rights Reserved
SUN PROPRIETARY/CONFIDENTIAL
Use is subject to license terms. -->

<helpset version="1.0" xml:lang="de">
	<title>Hilfe zu Sun Java(tm) System Message Queue-Administration Console</title>
	<maps>
		<homeID>overview</homeID>
		<mapref location="de/Master.jhm"/>
	</maps>
	<view>
		<name>TOC</name>
		<label>Inhalt</label>
		<type>javax.help.TOCView</type>
		<data>de/MasterTOC.xml</data>
	</view>
</helpset>
